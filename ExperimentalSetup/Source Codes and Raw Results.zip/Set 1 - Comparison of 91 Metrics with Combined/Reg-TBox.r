options( java.parameters = "-Xmx6g" )

getwd()
setwd("C:/ProgramExt/WS-R/ABox")
getwd()

library(plyr)                    # Progress bar
library(randomForest)
library(XLConnect)               # load XLConnect package 

wk = loadWorkbook("Data.xlsx") 
data = readWorksheet(wk, sheet="DataTBox")

nrow(data) # 5878

k = 10 #Folds

# sample from 1 to k, nrow times (the number of observations in the data)
data$id <- sample(1:k, nrow(data), replace = TRUE)
list <- 1:k  #  1  2  3  4  5  6  7  8  9 10

prediction <- data.frame()
testsetCopy <- data.frame()

progress.bar <- create_progress_bar("text")
progress.bar$init(k)

for (i in 1:k){
  trainingset <- subset(data, id %in% list[-i])
  testset <- subset(data, id %in% c(i))
  
  mymodel <- randomForest(NanoSecs ~ ., data = trainingset, ntree = 500) 
  
  temp <- as.data.frame(predict(mymodel, testset[,-1]))
  prediction <- rbind(prediction, temp)
  testsetCopy <- rbind(testsetCopy, as.data.frame(testset[,1]))
  
  progress.bar$step()
}

result <- cbind(prediction, testsetCopy[, 1])
names(result) <- c("Predicted", "Actual")
result$Difference <- abs(result$Actual - result$Predicted)

summary(result$Difference)

library(xlsx)
write.xlsx(result, "Results-DataTBox.xlsx")
detach("package:xlsx", TRUE)
